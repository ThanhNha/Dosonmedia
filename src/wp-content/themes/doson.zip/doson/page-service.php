<?php /* Template Name: Page Service */?>
<?php get_header(); ?>

<?php the_post();?>

<?php get_template_part('site-structure/page/page-service/index');?>

<?php get_footer(); ?>