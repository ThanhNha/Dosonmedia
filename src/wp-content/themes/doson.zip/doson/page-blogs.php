<?php /* Template Name: Page Blogs */?>
<?php get_header(); ?>

<?php the_post();?>

<?php get_template_part('site-structure/page/page-blogs/index');?>

<?php get_footer(); ?>