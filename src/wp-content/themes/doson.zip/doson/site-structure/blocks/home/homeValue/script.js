function homeValue() {
  $(".value-block span").counterUp({
    delay: 15,
    time: 3000,
  });
}
