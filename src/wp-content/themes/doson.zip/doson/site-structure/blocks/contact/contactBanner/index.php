<section id="contact-main-banner" class="contact-main-banner">
    <div class="banner-contact">
        <video id="video" autoplay muted playsinline loop>
            <source src="<?php the_field('contact_banner_video');?>" type="video/mp4" />
        </video>
    </div>
</section>