function blockSample(){
    
}