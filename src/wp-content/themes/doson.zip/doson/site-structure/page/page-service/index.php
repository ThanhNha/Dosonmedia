<main id="page-service">
    <div class="container-fluid p-0">
        <div class="row no-gutters">
            <div class="col">
                <?php the_content(); ?>
            </div>
        </div>
    </div>
</main>