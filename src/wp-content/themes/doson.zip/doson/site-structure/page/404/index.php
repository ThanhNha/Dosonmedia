<main id="page404">
    <section class="page_404">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 ">
                    <div class="col-sm-10 col-sm-offset-1  text-center">
                        <div class="four_zero_four_bg">
                            <h1 class="text-center ">404</h1>
                        </div>
                        <div class="contant_box_404">
                            <h1>Oops!</h1>
                            <h2 class="h2">404 - PAGE NOT FOUND</h2>
                            <h3>The page you are looking for might have been removed<br>
                                had its name changed or is temporarily unavailable.</h3>
                            <a class="btnStyle" href="/" title="Go To Homepage">
                                Go To Homepage
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>