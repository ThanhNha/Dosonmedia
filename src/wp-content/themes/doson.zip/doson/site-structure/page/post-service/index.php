<main id="single-service">
    <?php the_content();?>
</main>