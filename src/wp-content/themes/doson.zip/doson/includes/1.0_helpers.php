<?php
function helper_demo(){
    echo ABC;
}