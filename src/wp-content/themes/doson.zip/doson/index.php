<?php get_header(); ?>

<?php the_post();?>

<main class="indexPage">
    <h1>You shouldn't be here</h1>
</main>

<?php get_footer(); ?>