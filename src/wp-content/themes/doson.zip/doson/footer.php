<?php get_template_part( 'site-structure/footer/index' );?>
<?php wp_footer(); ?>
</body>
</html>